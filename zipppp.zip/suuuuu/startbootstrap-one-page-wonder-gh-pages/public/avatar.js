const vet = ['1','2','3','4','5','6'];

document.getElementById('mavatar1').addEventListener("click",function(e){
    e.preventDefault();
    document.getElementById('tares1').style.display = "block"; 
    document.getElementById('tares11').style.display = "block";
    document.getElementById('tares2').style.display = "none"; 
    document.getElementById('tares12').style.display = "none";
});
document.getElementById('mavatar2').addEventListener("click",function(e){
    e.preventDefault();
    document.getElementById('tares1').style.display = "none"; 
    document.getElementById('tares11').style.display = "none";
    document.getElementById('tares2').style.display = "block"; 
    document.getElementById('tares12').style.display = "block";
});
    
    
let iii = ['1','2','3'];
for(let i=0; i<3; i++){
    document.getElementById('selecionar'+iii[i]).addEventListener("click",function(e){
        e.preventDefault();
        document.getElementById('fisc'+iii[i]).style.display = "block";
        document.getElementById('fisc'+iii[i]).style.display = "block";
    });
}
let iid = ['1','2','3'];
for(let i=0; i<3; i++){
    document.getElementById('erro'+iid[i]).addEventListener("click",function(e){
        e.preventDefault();
        document.getElementById('perguntinha').style.display = "none";
    });
}

document.getElementById('erro').addEventListener("click",function(e){
    e.preventDefault();
    document.getElementById('modalogin1').style.display = "none";
});
let y = ['1','2','3'];
document.getElementById('bca').addEventListener("click",function(e){
        e.preventDefault();
        for(let i=0; i<3; i++){
        if(document.getElementById('taresB'+y[i]).style.display == 'block'){
            document.getElementById('taresB1'+y[i]).style.display = 'block';
        }
        if(document.getElementById('taresB2'+y[i]).style.display == 'block'){
            document.getElementById('taresB22'+y[i]).style.display = 'block';
        }
    }
});

document.getElementById('tboca1').addEventListener('click',function(e){
    e.preventDefault();
    if(document.getElementById('tares11').style.display == "block"){
        console.log('branco');
        
        document.getElementById('taresB1').style.display = 'block';
        document.getElementById('taresB2').style.display = 'none';
        document.getElementById('taresB3').style.display = 'none';
    }
    if(document.getElementById('tares12').style.display == "block"){
        console.log('preto');
        
        document.getElementById('taresB21').style.display = 'block';
        document.getElementById('taresB22').style.display = 'none';
        document.getElementById('taresB23').style.display = 'none';
    }
});
document.getElementById('tboca2').addEventListener('click',function(e){
    e.preventDefault();
    if(document.getElementById('tares11').style.display == "block"){
        document.getElementById('taresB1').style.display = 'none';
        document.getElementById('taresB2').style.display = 'block';
        document.getElementById('taresB3').style.display = 'none';
    }
    if(document.getElementById('tares12').style.display == "block"){
        document.getElementById('taresB21').style.display = 'none';
        document.getElementById('taresB22').style.display = 'block';
        document.getElementById('taresB23').style.display = 'none';
    }
});
document.getElementById('tboca3').addEventListener('click',function(e){
    e.preventDefault();
    if(document.getElementById('tares11').style.display == "block"){
        document.getElementById('taresB1').style.display = 'none';
        document.getElementById('taresB2').style.display = 'none';
        document.getElementById('taresB3').style.display = 'block';
    }
    if(document.getElementById('tares12').style.display == "block"){
        document.getElementById('taresB21').style.display = 'none';
        document.getElementById('taresB22').style.display = 'none';
        document.getElementById('taresB23').style.display = 'block';
    }
});

document.getElementById('tcabelo1').addEventListener('click',function(e){
    e.preventDefault();
    for(let i=0; i<3; i++){
        if(document.getElementById('taresB1'+y[i]).style.display == 'block'){            
            document.getElementById('taresB'+y[i]+'c1').style.display = 'block'
            document.getElementById('taresB'+y[i]+'c2').style.display = 'none'
            document.getElementById('taresB'+y[i]+'c3').style.display = 'none'
        }
        if(document.getElementById('taresB22'+y[i]).style.display == 'block'){            
            document.getElementById('taresPB'+y[i]+'c1').style.display = 'block'
            document.getElementById('taresPB'+y[i]+'c2').style.display = 'none'
            document.getElementById('taresPB'+y[i]+'c3').style.display = 'none'
        }
    }
});
document.getElementById('tcabelo2').addEventListener('click',function(e){
    e.preventDefault();
    for(let i=0; i<3; i++){
        if(document.getElementById('taresB1'+y[i]).style.display == 'block'){
            document.getElementById('taresB'+y[i]+'c1').style.display = 'none'
            document.getElementById('taresB'+y[i]+'c2').style.display = 'block'
            document.getElementById('taresB'+y[i]+'c3').style.display = 'none'
        }
        if(document.getElementById('taresB22'+y[i]).style.display == 'block'){            
            document.getElementById('taresPB'+y[i]+'c1').style.display = 'block'
            document.getElementById('taresPB'+y[i]+'c2').style.display = 'none'
            document.getElementById('taresPB'+y[i]+'c3').style.display = 'none'
        }
    }
});
document.getElementById('tcabelo3').addEventListener('click',function(e){
    e.preventDefault();
    for(let i=0; i<3; i++){
        if(document.getElementById('taresB1'+y[i]).style.display == 'block'){
            document.getElementById('taresB'+y[i]+'c1').style.display = 'none'
            document.getElementById('taresB'+y[i]+'c2').style.display = 'none'
            document.getElementById('taresB'+y[i]+'c3').style.display = 'block'
        }
        if(document.getElementById('taresB22'+y[i]).style.display == 'block'){            
            document.getElementById('taresPB'+y[i]+'c1').style.display = 'block'
            document.getElementById('taresPB'+y[i]+'c2').style.display = 'none'
            document.getElementById('taresPB'+y[i]+'c3').style.display = 'none'
        }
    }
});

document.getElementById('tacesso1').addEventListener('click',function(e){
    e.preventDefault();
    document.getElementById('taresA1').style.display = 'block';
    document.getElementById('taresA2').style.display = 'none';
    document.getElementById('taresA3').style.display = 'none';
});
document.getElementById('tacesso2').addEventListener('click',function(e){
    e.preventDefault();
    document.getElementById('taresA1').style.display = 'none';
    document.getElementById('taresA2').style.display = 'block';
    document.getElementById('taresA3').style.display = 'none';
});
document.getElementById('tacesso3').addEventListener('click',function(e){
    e.preventDefault();
    document.getElementById('taresA1').style.display = 'none';
    document.getElementById('taresA2').style.display = 'none';
    document.getElementById('taresA3').style.display = 'block';
});
document.getElementById('tudo').addEventListener('click',function(e){
    e.preventDefault();
    document.getElementById('avatarteste1').style.display = "block";
    document.getElementById('dado').style.display = "block";  
});
document.getElementById('no').addEventListener('click',function(){
    document.getElementById('delito').style.display = 'none';
});


let dado = document.getElementById('dado');
let guarda=0;
let pontos = 0;
const vetor = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
const topp = [80,76,58,41,26,9,9,27,43,60,75,80,80,62,46,30,13,6,6,10,29,29,49,80];
const leftt = [7,16,13,9,3,8,19,21,26,30,37,46,56,56.5,51,46,41,50,59.5,69,71.5,82,83,83];
const vp = ['Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.'];
const dic = ['Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.','Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsa ipsam sequi! Rerum fuga distinctio nobis repudiandae rem adipisci aliquid, ullam officiis in magni eveniet ratione sit. Harum, magni nulla?Lorem ipsum dolor sit amet consectetur adipisicing elit.'];
const gabarito = ['a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a'];
let i = 0;
let za = 0;
let ifrs = 0;
let lemos = 0;
let helena = 0;
let bom = 0;

const db = firebase.database();
const tbody = document.getElementById('tbody');
const tbody1 = document.getElementById('tbody1');
const tbody2 = document.getElementById('tbody2');
const tbody3 = document.getElementById('tbody3');
const tbody4 = document.getElementById('tbody4');

let num = 1;
let j = 0;
let clas = ["bg-info","oi","bg-danger","oi","bg-warning","oi","bg-success","oi","bg-primary"];
let v = ['b1','b2','b3','b4'];
let v2 = ['/alunosifrs','/alunoslemos','/alunoshelena','/alunosbom'];
let data = [];

dado.addEventListener("click",function(e){
    e.preventDefault();
    let num = Math.floor(Math.random() * 6) + 1;
    guarda += num;
    
    for (let i = 0; i < vetor.length; i++) {
            if(guarda == vetor[i]){

                document.getElementById('avatarteste1').style.top = topp[i] + '%';
                document.getElementById('avatarteste1').style.left = leftt[i] + '%';

                let teste = topp[i];
                let teste2 = leftt[i];

                if (teste == topp[i] && leftt[i]){
                    document.getElementById('perguntinha').style.display = 'block';
                    p = document.getElementById('perg');
                    p.textContent = vp[i];
                    document.getElementById('dicaa').textContent = dic[i];
                        if (document.getElementById('erro1').textContent == gabarito[i]) {
                            pontos ++;                           
                            document.getElementById('pontos').innerHTML = pontos;                            
                    }
        }
        if(guarda == 5 || guarda == 10 || guarda == 15 || guarda == 20){
            document.getElementById('delito').style.display = 'block';
    
            pontos --;                           
            document.getElementById('pontos').innerHTML = pontos;
    
            document.getElementById('avatarteste1').style.top = topp[i-1] + '%';
            document.getElementById('avatarteste1').style.left = leftt[i-1] + '%';
            document.getElementById('perguntinha').style.display = 'none';
        }
    }
        if(guarda >= 24){
            document.getElementById('avatarteste1').style.top = 80 + '%';
            document.getElementById('avatarteste1').style.left = 83 + '%';
        } 
}
if(guarda > 24){
    document.getElementById('nav2').style.display = "block";
    document.getElementById('some').style.display = "none";
    document.getElementById('ranking').style.display = "block";

    db.ref('/cadastro').on('child_added', function(item) {
        var c1 = item.val().email;
        if(localStorage.getItem('usuario') == c1){
            var c = item.key;
            var cadastro = {
                nome:item.val().nome,
                idade:item.val().idade,
                cidade:item.val().cidade,
                escola:item.val().escola,
                email:item.val().email,
                senha:item.val().senha,
                pontos:item.val().pontos + pontos
            }
            db.ref('/cadastro').child(c).set(cadastro);
                
            var esc = item.val().escola;
            var email = item.val().email; 
            if(esc == 'IFRS'){
                ifrs = pontos;
                db.ref('/alunosifrs').on('child_added', function(item) {
                    if(email == item.val().email){
                        var chave = item.key;
                        
                        db.ref('/alunosifrs').child(chave).set(cadastro);
                    }
                });
                }
            if(esc == 'Lemos'){
                lemos = pontos;
                db.ref('/alunoslemos').on('child_added', function(item) {
                    if(email == item.val().email){
                        var chave2 = item.key;
                        
                        db.ref('/alunoslemos').child(chave2).set(cadastro);
                    }
                });
                }
            if(esc == 'Bom Jesus'){
                bom = pontos;
                db.ref('/alunosbom').on('child_added', function(item) {
                    if(email == item.val().email){
                        var chave3 = item.key;
                        
                        db.ref('/alunosbom').child(chave3).set(cadastro);
                    }
                });
                }
            if(esc == 'Helena'){
                helena = pontos;
                db.ref('/alunoshelena').on('child_added', function(item) {
                    if(email == item.val().email){
                        var chave4 = item.key;
                        
                        db.ref('/alunoshelena').child(chave4).set(cadastro);
                    }
                });
                }
            var escola = {
                ifrs:ifrs,
                lemos:lemos,
                bom_jesus:bom,
                helena:helena
            }
            db.ref('/escola').child('o').set(escola);
            }
});        
db.ref('/escola').on('child_added', function(item) {
        let guardaIFRS = item.val().ifrs;
        let guardalemos = item.val().lemos;
        let guardahelena = item.val().helena;
        let guardabom = item.val().bom_jesus;

        db.ref('/contador').on('child_added', function(item) {      
            let ifrs1 = item.val();
            ifrs1 += guardaIFRS;
            db.ref('/contador').child('conta').set(ifrs1);

        db.ref('/contadorLemos').on('child_added', function(item) {   
            let lemos1 = item.val();
            lemos1 += guardalemos;
            db.ref('/contadorLemos').child('contaLemos').set(lemos1);

        db.ref('/contadorHelena').on('child_added', function(item) {   
            let helena1 = item.val();
            helena1 += guardahelena;
            db.ref('/contadorHelena').child('contaHelena').set(helena1);

        db.ref('/contadorBom').on('child_added', function(item) {   
            let bom1 = item.val();
            bom1 += guardabom;
            db.ref('/contadorBom').child('contaBom').set(bom1);        
        
        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '1';
        var td = document.createElement('td');
        td.textContent = ' IFRS ';
        var td2 = document.createElement('td');
        td2.textContent = '   '+ifrs1;
        var tr = document.createElement('tr');
        tr.className = "bg-info";
        var button = document.createElement('button');
        button.textContent = 'Detalhes';
        button.className = "btn btn-danger";
        button.setAttribute("id", "b1");
        button.setAttribute("data-toggle", "modal");
        button.setAttribute("data-target", "#listaif");
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tr.appendChild(button);
        tbody.appendChild(tr);  
        
        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '';
        var td = document.createElement('td');
        td.textContent = '';
        var td2 = document.createElement('td');
        td2.textContent = '';
        var tr = document.createElement('tr');
        tr.className = "oi";
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tbody.appendChild(tr);  

        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '2';
        var td = document.createElement('td');
        td.textContent = ' LEMOS ';
        var td2 = document.createElement('td');
        td2.textContent = '   '+lemos1;
        var tr = document.createElement('tr');
        tr.className = "bg-danger";
        var button = document.createElement('button');
        button.textContent = 'Detalhes';
        button.className = "btn btn-warning";
        button.setAttribute("id", "b2");
        button.setAttribute("data-toggle", "modal");
        button.setAttribute("data-target", "#listalemos");
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tr.appendChild(button);
        tbody.appendChild(tr);  

        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '';
        var td = document.createElement('td');
        td.textContent = '';
        var td2 = document.createElement('td');
        td2.textContent = '';
        var tr = document.createElement('tr');
        tr.className = "oi";
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tbody.appendChild(tr);  

        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '3';
        var td = document.createElement('td');
        td.textContent = ' HELENA ';
        var td2 = document.createElement('td');
        td2.textContent = '   '+helena1;
        var tr = document.createElement('tr');
        tr.className = "bg-warning";
        var button = document.createElement('button');
        button.textContent = 'Detalhes';
        button.className = "btn btn-success";
        button.setAttribute("id", "b3");
        button.setAttribute("data-toggle", "modal");
        button.setAttribute("data-target", "#listahelena");
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tr.appendChild(button);
        tbody.appendChild(tr);  

        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '';
        var td = document.createElement('td');
        td.textContent = '';
        var td2 = document.createElement('td');
        td2.textContent = '';
        var tr = document.createElement('tr');
        tr.className = "oi";
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tbody.appendChild(tr);  

        var th = document.createElement('th');
        th.setAttribute("scope", "row");
        th.textContent = '4';
        var td = document.createElement('td');
        td.textContent = ' BOM JESUS ';
        var td2 = document.createElement('td');
        td2.textContent = bom1;
        var tr = document.createElement('tr');
        tr.className = "bg-success";
        var button = document.createElement('button');
        button.className = "btn btn-info";
        button.setAttribute("id", "b4");
        button.setAttribute("data-toggle", "modal");
        button.setAttribute("data-target", "#listabom");
        button.textContent = 'Detalhes';
        tr.appendChild(th);
        tr.appendChild(td);
        tr.appendChild(td2);
        tr.appendChild(button);
        tbody.appendChild(tr);
        
            db.ref('/alunosifrs').on('child_added', function(item) {
                    
                    var th = document.createElement('th');
                    th.setAttribute("scope", "row");
                    th.textContent = '#';
                    var td = document.createElement('td');
                    td.textContent = item.val().nome;
                    var td2 = document.createElement('td');
                    td2.textContent = item.val().idade;
                    var td3 = document.createElement('td');
                    td3.textContent = item.val().pontos;
                    var tr = document.createElement('tr');
                    tr.className = clas[j];
                    tr.appendChild(th);
                    tr.appendChild(td);
                    tr.appendChild(td2);
                    tr.appendChild(td3);
                    tbody1.appendChild(tr);
                    tbody1.setAttribute("style", "overflow-y:scroll");
                    j++
            });

            db.ref('/alunoslemos').on('child_added', function(item) {   
                var th = document.createElement('th');
                th.setAttribute("scope", "row");
                th.textContent = '#';
                var td = document.createElement('td');
                td.textContent = item.val().nome;
                var td2 = document.createElement('td');
                td2.textContent = item.val().idade;
                var td3 = document.createElement('td');
                td3.textContent = item.val().pontos;
                var tr = document.createElement('tr');
                tr.className = clas[j];
                tr.appendChild(th);
                tr.appendChild(td);
                tr.appendChild(td2);
                tr.appendChild(td3);
                tbody2.appendChild(tr);
                tbody2.setAttribute("style", "overflow-y:scroll");
                j++
            });

            db.ref('/alunoshelena').on('child_added', function(item) {   
                var th = document.createElement('th');
                th.setAttribute("scope", "row");
                th.textContent = '#';
                var td = document.createElement('td');
                td.textContent = item.val().nome;
                var td2 = document.createElement('td');
                td2.textContent = item.val().idade;
                var td3 = document.createElement('td');
                td3.textContent = item.val().pontos;
                var tr = document.createElement('tr');
                tr.className = clas[j];
                tr.appendChild(th);
                tr.appendChild(td);
                tr.appendChild(td2);
                tr.appendChild(td3);
                tbody3.appendChild(tr);
                tbody3.setAttribute("style", "overflow-y:scroll");
                j++
            });

            db.ref('/alunosbom').on('child_added', function(item) {   
                var th = document.createElement('th');
                th.setAttribute("scope", "row");
                th.textContent = '#';
                var td = document.createElement('td');
                td.textContent = item.val().nome;
                var td2 = document.createElement('td');
                td2.textContent = item.val().idade;
                var td3 = document.createElement('td');
                td3.textContent = item.val().pontos;
                var tr = document.createElement('tr');
                tr.className = clas[j];
                tr.appendChild(th);
                tr.appendChild(td);
                tr.appendChild(td2);
                tr.appendChild(td3);
                tbody4.appendChild(tr);
                tbody4.setAttribute("style", "overflow-y:scroll");
                j++
            });





    });
    });
});
});

});

    }
    });


